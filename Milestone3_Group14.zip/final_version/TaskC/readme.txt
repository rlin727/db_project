For all of our csv files, we use python to randomly made up.
For create.sql and load.sql files
The database name is 'DB_PROJ' in mysql.
We will directly load Comments.csv, Drivers.csv, Restaurants.csv
For Customers_and_Address.csv, we will load as Customers table and Customers_address table.
For Orders_and_Delivery.csv, we will load as Orders table and Delivery_by table.

Since we do not use bewtaweb as our server, we cannot upload csv files on our Google server 
and the load.sql we provided cannot run on our server.