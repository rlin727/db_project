<!DOCTYPE html>
<html lang="en">

<head>
    <title>Orders</title>

    <style>
        table {
        border-collapse: collapse;
        width: 85%;
        color: #333333;
        font-family: monospace;
        font-size: 24px;
        text-align: left;
        }
        th{
            background-color: #666666;
            color: white;
        }
        tr:nth-child(even) {background-color: #f2f2f2}
    </style>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="../../html/home.html">Food Delivery DBMS</a>
          </div>
        <ul class="nav navbar-nav">
          <li><a href="../../html/register.html">Register</a></li>
          <li><a href="../../html/table.html">Tables</a></li>
          <li><a href="../../html/search.html">Search</a></li>
        </ul>
      </div>
  </nav>

<form>
<div align="left" style="position:relative;top:10px">
  <button type="submit" class="btn btn-primary" formaction="../../html/search/search_orders.html">Back</button>
  <br>
</div>
</form>

<div class="jumbotron text-center">
    <h1>Orders Table</h1>
</div>

<table align="center">
    <tr>
        <th>Order ID</th>
        <th>Customer ID</th>
        <th>Driver ID</th>
        <th>Restaurant ID</th>
        <th>Time</th>
        <th>Software</th>
        <th>Delivery Address</th>
        <th>Payment Method</th>
        <th>Price</th>
        <th>Delivery Instruction</th>
    </tr>

    <?php
    $server = "db.wumingumou.com";
    $user = "root";
    $password = "123456";
    $db = "DB_PROJ";
    $conn = new mysqli($server, $user, $password, $db);
    $sql_input = 'SELECT * FROM Orders WHERE ';


    $Street_Line = $_POST['Street_Line'];
    $city = $_POST['city'];
    $state = $_POST['State'];
    $zipcode = $_POST['zipcode'];
    $Delivery_Address =  $Street_Line . ' ' . $city . ', ' . $state . ' ' . $zipcode;
    if ($_POST['Order_id'] != ''){
        $Order_id = $_POST['Order_id'];
        $sql_input = $sql_input. 'Order_id = \''. $Order_id. '\' AND ';
    }
    if ($_POST['Cust_id'] != ''){
        $Cust_id = $_POST['Cust_id'];
        $sql_input = $sql_input. 'Cust_id = \''. $Cust_id. '\' AND ';
    }
    if ($_POST['Driver_id'] != ''){
        $Driver_id = $_POST['Driver_id'];
        $sql_input = $sql_input. 'Driver_id = \''. $Driver_id. '\' AND ';
    }
    if ($_POST['Rest_id'] != ''){
        $Rest_id = $_POST['Rest_id'];
        $sql_input = $sql_input. 'Rest_id = \''. $Rest_id. '\' AND ';
    }
    if ($_POST['Time'] != ''){
        $Time = $_POST['Time'];
        $sql_input = $sql_input. 'Time = \''. $Time. '\' AND ';
    }
    if ($_POST['Software'] != ''){
        $Software = $_POST['Software'];
        $sql_input = $sql_input. 'Software = \''. $Software. '\' AND ';
    }
    if ($Delivery_Address != ' ,  '){
        $Delivery_Address = $_POST['Delivery_Address'];
        $sql_input = $sql_input. 'Delivery_Address = \''. $Delivery_Address. '\' AND ';
    }
    if ($_POST['Payment_Method'] != ''){
        $Payment_Method = $_POST['Payment_Method'];
        $sql_input = $sql_input. 'Payment_Method = \''. $Payment_Method. '\' AND ';
    }
    if ($_POST['Price'] != ''){
        $Price = $_POST['Price'];
        $sql_input = $sql_input. 'Price = \''. $Price. '\' AND ';
    }
    if ($_POST['Delivery_Instruction'] != ''){
        $Delivery_Instruction = $_POST['Delivery_Instruction'];
        $sql_input = $sql_input. 'Delivery_Instruction = \''. $Delivery_Instruction. '\' AND ';
    }


    $sql_input = $sql_input.'Order_id>0;';

    $result = $conn->query($sql_input);

    if ($result-> num_rows > 0){
        while ($row = $result-> fetch_assoc()){
            echo "<tr><td>" . $row["Order_id"]. "</td><td>" . $row["Cust_id"]."</td><td>"
            . $row["Driver_id"]."</td><td>" . $row["Restaurant_id"]. "</td><td>" . $row["Time"] .
            "</td><td>". $row["Software"] ."</td><td>". $row["Delivery_Address"] .
            "</td><td>". $row["Payment_Method"] ."</td><td>". $row["Price"] .
            "</td><td>". $row["Delivery_Instruction"] ."</td></tr>";
        }
        echo "</table>";
    }
    ?>
</table>

<div id="footer" style="position:bottom;clear:both;text-align:center;">
    <br>
        Created by: Deyao Kong, Rui Lin, Zihao Xu
    <br>
</div>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>