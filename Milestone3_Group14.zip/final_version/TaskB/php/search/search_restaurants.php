<!DOCTYPE html>
<html lang="en">

<head>
    <title>Restaurant</title>

    <style>
        table {
        border-collapse: collapse;
        width: 85%;
        color: #333333;
        font-family: monospace;
        font-size: 24px;
        text-align: left;
        }
        th{
            background-color: #666666;
            color: white;
        }
        tr:nth-child(even) {background-color: #f2f2f2}
    </style>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="../../html/home.html">Food Delivery DBMS</a>
          </div>
        <ul class="nav navbar-nav">
          <li><a href="../../html/register.html">Register</a></li>
          <li><a href="../../html/table.html">Tables</a></li>
          <li><a href="../../html/search.html">Search</a></li>
        </ul>
      </div>
  </nav>

<form>
<div align="left" style="position:relative;top:10px">
  <button type="submit" class="btn btn-primary" formaction="../../html/search/search_restaurants.html">Back</button>
  <br>
</div>
</form>

<div class="jumbotron text-center">
    <h1>Restaurant Table</h1>
</div>

<table align="center">
    <tr>
        <th>Restaurant ID</th>
        <th>Name</th>
        <th>Address</th>
        <th>Phone Number</th>
        <th>Email</th>
        <th>Website</th>
        <th>Category</th>
    </tr>

    <?php
    $server = "db.wumingumou.com";
    $user = "root";
    $password = "123456";
    $db = "DB_PROJ";
    $conn = new mysqli($server, $user, $password, $db);
    $sql_input = 'SELECT * FROM Restaurants
                  WHERE ';
    if ($_POST['Restaurant_id'] != ''){
        $Restaurant_id = $_POST['Restaurant_id'];
        $sql_input = $sql_input. 'Restaurant_id = \''. $Restaurant_id. '\' AND ';
    }
    if ($_POST['Name'] != ''){
        $Name = $_POST['Name'];
        $sql_input = $sql_input. 'Name = \''. $Name. '\' AND ';
    }
    if ($_POST['Category'] != ''){
        $Category = $_POST['Category'];
        $sql_input = $sql_input. 'Category = \''. $Category. '\' AND ';
    }
    if ($_POST['Phone_Num'] != ''){
        $Phone_Num = $_POST['Phone_Num'];
        $sql_input = $sql_input. 'Phone_Num = \''. $Phone_Num. '\' AND ';
    }
    if ($_POST['Email'] != ''){
        $Email = $_POST['Email'];
        $sql_input = $sql_input. 'Email = \''. $Email. '\' AND ';
    }
    if ($_POST['Website'] != ''){
        $Website = $_POST['Website'];
        $sql_input = $sql_input. 'Website = \''. $Website. '\' AND ';
    }
    if ($_POST['Street_Line'] != ''){
        $Street_Line = $_POST['Street_Line'];
        $city = $_POST['city'];
        $state = $_POST['State'];
        $zipcode = $_POST['zipcode'];
        $address =  $Street_Line . ' ' . $city . ', ' . $state . ' ' . $zipcode;
        $sql_input = $sql_input. 'address = \''. $address. '\' AND ';

    }

    $sql_input = $sql_input.'Restaurant_id>0;';

    $result = $conn->query($sql_input);

    if ($result-> num_rows > 0){
        while ($row = $result-> fetch_assoc()){
            echo "<tr><td>" . $row["Restaurant_id"]. "</td><td>" . $row["Name"] .
            "</td><td>". $row["Address"] ."</td><td>". $row["Phone_Num"] .
            "</td><td>". $row["Email"] ."</td><td>". $row["Website"] .
            "</td><td>". $row["Category"] ."</td></tr>";
        }
        echo "</table>";
    }
    ?>
</table>

<div id="footer" style="position:bottom;clear:both;text-align:center;">
    <br>
        Created by: Deyao Kong, Rui Lin, Zihao Xu
    <br>
</div>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>