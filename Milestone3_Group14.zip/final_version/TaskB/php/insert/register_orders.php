<!DOCTYPE html>
<html lang="en">
<head>
  <title>Restaurant</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="../../html/home.html">Food Delivery DBMS</a>
          </div>
        <ul class="nav navbar-nav">
          <li><a href="../../html/register.html">Register</a></li>
          <li><a href="../../html/table.html">Tables</a></li>
          <li><a href="../../html/search.html">Search</a></li>
        </ul>
      </div>
  </nav>


<?php

$server = "db.wumingumou.com";
$user = "root";
$password = "123456";
$db = "DB_PROJ";
$conn = new mysqli($server, $user, $password, $db);

$Order_id = $_POST['Order_id'];
$Cust_id = $_POST['Cust_id'];
$Driver_id = $_POST['Driver_id'];
$Rest_id = $_POST['Rest_id'];

$Time = $_POST['Time'];
$Software = $_POST['Software'];
$Street_Line = $_POST['Street_Line'];
$City = $_POST['city'];
$State = $_POST['state'];
$Zipcode = $_POST['zipcode'];
$Delivery_Address = $Street_Line . ' ' . $City . ', ' . $State . ' ' . $Zipcode;
$Payment_Method = $_POST['Payment_Method'];
$Price = $_POST['Price'];
$Delivery_Instruction = $_POST['Delivery_Instruction'];
$Tips = $_POST['Tips'];


#SQL insert 
$sql_insert1 = "INSERT INTO Orders VALUES ('$Order_id','$Cust_id', '$Driver_id', '$Rest_id', '$Time', '$Software','$Delivery_Address','$Payment_Method', '$Price', '$Delivery_Instruction')";

$sql_insert2 = "INSERT INTO Delivered_By VALUES ('$Order_id', '$Driver_id', '$Tips')";
echo "<br>";
if($result = $conn->query($sql_insert1) && $result = $conn->query($sql_insert2)) { 
echo "<div align = \"center\">";
echo "<img src=\"image/success.png\" alt=\"error\" width=\"320\" height=\"397\">";
echo "</div>";

echo "<form>";
echo "<div align=\"center\" style=\"position:relative;top:10px\">";
echo   "<button type=\"submit\" class=\"btn btn-primary\" formaction=\"../../html/register.html\">Add New One</button>";
echo   "<br>";
echo "</div>";
echo "</form>";
} else { 
echo "<div align = \"center\">";
echo  "<h1>Insert Failed!</h1>";
echo  "<p>Try again!</p> ";
echo "<img src=\"image/error.png\" alt=\"error\" width=\"1000\" height=\"500\">";
echo "</div>";

echo "<form>";
echo "<div align=\"center\" style=\"position:relative;top:10px\">";
echo   "<button type=\"submit\" class=\"btn btn-primary\" formaction=\"../../html/register.html\">Try Again</button>";
echo   "<br>";
echo "</div>";
echo "</form>";
}

?>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>
