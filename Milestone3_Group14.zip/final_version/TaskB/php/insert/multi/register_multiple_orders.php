<!DOCTYPE html>
<html lang="en">
<head>
  <title>Restaurant</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="../../../html/home.html">Food Delivery DBMS</a>
          </div>
        <ul class="nav navbar-nav">
          <li><a href="../../../html/register.html">Register</a></li>
          <li><a href="../../../html/table.html">Tables</a></li>
          <li><a href="../../../html/search.html">Search</a></li>
        </ul>
      </div>
  </nav>
<form>
	<div align="left" style="position:relative;top:10px">
		<button type="submit" class="btn btn-primary" formaction = "../../../html/register/register_restaurants.html">Back</button>
		<br>
    <br>
    <br>
	</div>
</form>
<?php

$server = "db.wumingumou.com";
$user = "root";
$password = "123456";
$db = "DB_PROJ";
$conn = new mysqli($server, $user, $password, $db);



$fh = fopen($_FILES["orders"]["tmp_name"], "r");
if ($fh === false) { exit("Failed to open uploaded CSV file"); }
echo "File opened Correctly"."<br>";
fgetcsv($fh);
while (($row = fgetcsv($fh)) !== false) {
    $sql_insert = "INSERT INTO Orders VALUES ('$row[0]','$row[1]','$row[2]', '$row[3]', '$row[4]', '$row[5]', '$row[6]', '$row[7]', '$row[8]', '$row[9]')";
    $sql_insert2 = "INSERT INTO Delivered_By VALUES ('$row[0]','$row[2]','$row[10]')";
    if ($conn -> query($sql_insert) && $conn -> query($sql_insert2)){
        print_r("Successful");
    }
    else{
        echo "ERROR ".mysqli_error($conn);
    }
    echo "<br>";
}

?>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>
