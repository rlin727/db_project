<!DOCTYPE html>
<html lang="en">
<head>
    <title>Delivery</title>

    <style>
        table {
        border-collapse: collapse;
        width: 85%;
        color: #333333;
        font-family: monospace;
        font-size: 24px;
        text-align: left;
        }
        th{
            background-color: #666666;
            color: white;
        }
        tr:nth-child(even) {background-color: #f2f2f2}
    </style>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-default">
      <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="../../html/home.html">Food Delivery DBMS</a>
          </div>
        <ul class="nav navbar-nav">
          <li><a href="../../html/register.html">Register</a></li>
          <li><a href="../../html/table.html">Tables</a></li>
          <li><a href="../../html/search.html">Search</a></li>
        </ul>
      </div>
  </nav>

<form>
<div align="left" style="position:relative;top:10px">
  <button type="submit" class="btn btn-primary" formaction="../../html/table.html">Back</button>
  <br>
</div>
</form>

<div class="jumbotron text-center">
    <h1>Delivery Table</h1>
</div>

<table align="center">
    <tr>
        <th>Order ID</th>
        <th>Driver ID</th>
        <th>Tips</th>
    </tr>
    <?php
    $server = "db.wumingumou.com";
    $user = "root";
    $password = "123456";
    $db = "DB_PROJ";
    $conn = new mysqli($server, $user, $password, $db);
    $sql = "SELECT * FROM Delivered_By";
    $result = $conn->query($sql);
    if ($result-> num_rows > 0){
        while ($row = $result-> fetch_assoc()){
            echo "<tr><td>" . $row["Order_id"]. "</td><td>" . $row["Driver_id"] .
            "</td><td>". $row["Tips"] ."</td></tr>";
        }
        echo "</table>";
    }
    ?>
</table>

<div id="footer" style="position:bottom;clear:both;text-align:center;">
    <br>
        Created by: Deyao Kong, Rui Lin, Zihao Xu
    <br>
</div>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>