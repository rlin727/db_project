Home page:
Welcome page.
http://betaweb.csug.rochester.edu/~dkong3/DB_PROJ/taskB/html/home.html

Register Page:
You can register new single record into existed database or update multiple records by uploading files.

http://betaweb.csug.rochester.edu/~dkong3/DB_PROJ/taskB/html/register.html

Table Page: 
You can access all tables here.

http://betaweb.csug.rochester.edu/~dkong3/DB_PROJ/taskB/html/table.html


Search Table:
You can search desired record.

http://betaweb.csug.rochester.edu/~dkong3/DB_PROJ/taskB/html/search.html